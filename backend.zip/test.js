// const cars = ["mercedeez", "bmw"];

// // for (const car of cars) {
// //     for (const carValue of car) {
// //         console.log(carValue);
// //     }
// //     console.log();
// // }

// // // using primitive for loop
// // for (let i = 0; i < cars.length; i++) {
// //     for (let j = 0; j < cars[i].length; j++) {
// //         console.log(cars[i][j]);
// //     }
// //     console.log("");
// // }

// cars.forEach((value, index,arr)=>{
    
// })
